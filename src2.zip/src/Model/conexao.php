<?php
    
    //parâmetros de acesso ao BD
    $servidor = "200.18.128.52";
    $usuario = "caio_isabella";
    $senha = "caio_isabella";
    $nomeBD = "caio_isabella";
    $con = new mysqli($servidor, $usuario, $senha, $nomeBD);
?>