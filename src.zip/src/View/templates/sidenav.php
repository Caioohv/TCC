<div class="sidenav">
    <div class="side-header">
        <a href="../../index.php"><h1>Início</h1></a>
        <a href="../caixa/cadastrarCaixa.php"><img src="../styles/icons/UserIcon.png" alt=""></a>
        <a href="../login/login.php"><img src="../styles/icons/logout.png" alt=""></a>
    </div>
    <div class="links">
        <!-- Colocar 'class="selected" onde for o selecionado' -->
        <p><a href="cadastarADM.php" class="link">Cadastrar Admin</a></p>
        <p><a href="editarADM.php" class="link">Editar Admin</a></p>
        <p><a href="visualizarADM.php" class="link">Visualizar Admin</a></p>
        <p><a href="validarADM.php" class="link">Validar Admin</a></p>
    </div>
</div>


<!-- class="selected" -->